UCSC Sinhala tagset V1

This resource is free for research and for producing software that is distributed under open source licenses. See the LGPL-LR license for more details: http://www.cnrtl.fr/lexiques/prolex/licence_lgpl-lr.php

It can be dual licensed for commercial use by contacting us at the address and email below.

Language Technology Research Laboratory,
University of Colombo School of Comparing,
No: 35, Reid Avenue,
Colombo 00700.


Web:	ltrl.ucsc.lk
email:	ltrl@ucsc.lk
Phone:	011-215-8962